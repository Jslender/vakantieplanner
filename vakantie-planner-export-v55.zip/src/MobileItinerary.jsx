import React, { useMemo } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";
import { formatDuration, formatKm } from "./utils/route.js";

// Read-only, phone-friendly day viewer (no map) with prev/next
export default function MobileItinerary({ tripName, startDateISO, days, dayNumberOverride }) {
  const nav = useNavigate();
  const params = useParams();

  const baseUrl = (import.meta?.env?.BASE_URL || "/");

  const safeDays = Array.isArray(days) ? days : [];
  const dayNumParam = Number(dayNumberOverride ?? params.dayNumber ?? 1);
  const dayNumber = Number.isFinite(dayNumParam) && dayNumParam > 0 ? dayNumParam : 1;

  const dayIndex = useMemo(() => {
    const idx = safeDays.findIndex(d => Number(d.dayNumber) === Number(dayNumber));
    return idx >= 0 ? idx : 0;
  }, [safeDays, dayNumber]);

  const day = safeDays[dayIndex] || null;

  const tripRange = useMemo(() => {
    if (!startDateISO || !safeDays.length) return "";
    const d0 = new Date(startDateISO + "T00:00:00");
    const dEnd = new Date(d0.getTime() + (safeDays.length - 1) * 24 * 60 * 60 * 1000);
    const fmt = (d) => d.toLocaleDateString("nl-NL", { weekday: "long", year: "numeric", month: "long", day: "numeric" });
    return `${fmt(d0)} t/m ${fmt(dEnd)}`;
  }, [startDateISO, safeDays]);

  const dayDateLabel = useMemo(() => {
    if (!startDateISO || !day) return "";
    const d0 = new Date(startDateISO + "T00:00:00");
    const d = new Date(d0.getTime() + (day.dayNumber - 1) * 24 * 60 * 60 * 1000);
    return d.toLocaleDateString("nl-NL", { weekday: "long", year: "numeric", month: "long", day: "numeric" });
  }, [startDateISO, day]);

  const transportLabel = (m) => {
    switch (m) {
      case "auto": return "Auto";
      case "vliegtuig": return "Vliegtuig";
      case "boot": return "Boot";
      case "trein": return "Trein";
      case "geen": return "Geen (verblijfsdag)";
      default: return m || "-";
    }
  };

  const money = (v) => {
    if (v == null || v === "") return "";
    const n = Number(v);
    if (!Number.isFinite(n)) return String(v);
    return n.toLocaleString("nl-NL", { style: "currency", currency: "EUR" });
  };

  const mapsSearchUrl = (q) => {
    const query = (q || "").trim();
    if (!query) return null;
    return `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(query)}`;
  };

  const mapsDirUrl = (dest) => {
    // dest can be {lat,lng} or string
    if (!dest) return null;
    if (typeof dest === "string") {
      const q = dest.trim();
      if (!q) return null;
      return `https://www.google.com/maps/dir/?api=1&destination=${encodeURIComponent(q)}`;
    }
    const lat = Number(dest.lat);
    const lng = Number(dest.lng);
    if (!Number.isFinite(lat) || !Number.isFinite(lng)) return null;
    return `https://www.google.com/maps/dir/?api=1&destination=${lat},${lng}`;
  };

  const openUrl = (url) => {
    if (!url) return;
    // Mobile browsers (and especially iOS PWAs) can be… precious about window.open.
    // Try open in a new tab; if blocked, fall back to same-tab navigation.
    const w = window.open(url, "_blank");
    if (!w) window.location.href = url;
  };

  const goDay = (n) => {
    const nn = Math.max(1, Math.min(safeDays.length || 1, n));
    nav(`/mobiel/${nn}`);
  };

  const autoLink = (text) => {
    const t = String(text || "");
    if (!t.trim()) return null;
    const parts = t.split(/(https?:\/\/[^\s]+)/g);
    return parts.map((p, i) => {
      if (/^https?:\/\//.test(p)) {
        return <a key={i} href={p} target="_blank" rel="noreferrer">{p}</a>;
      }
      return <span key={i}>{p}</span>;
    });
  };

  if (!day) {
    return (
      <div className="mobileWrap">
        <header className="mobileHeader">
          <div className="mobileTopRow">
            <div>
              <div className="mobileTrip">{tripName || "Reis"}</div>
              <div className="mobileSub">{tripRange || "Geen dagen gevonden."}</div>
            </div>
            <a className="mobileBack" href={baseUrl}>Planner</a>
          </div>
        </header>
        <main className="mobileCard">
          <div className="mobileEmpty">Geen dagen gevonden.</div>
        </main>
      </div>
    );
  }

  const dayTitle = `Dag ${day.dayNumber}`;

  const segs = Array.isArray(day.flightSegments) ? day.flightSegments : [];

  const flightFrom = (s) => {
    const v =
      (s?.from ?? s?.van ?? s?.origin ?? s?.fromText ?? s?.fromLabel ?? s?.fromName) ??
      (s?.fromPlace?.label ?? s?.fromPlace?.name) ??
      (s?.fromAirport?.label ?? s?.fromAirport?.name) ??
      "";
    return typeof v === "string" ? v : (v?.label || v?.name || "");
  };

  const flightTo = (s) => {
    const v =
      (s?.to ?? s?.naar ?? s?.destination ?? s?.toText ?? s?.toLabel ?? s?.toName) ??
      (s?.toPlace?.label ?? s?.toPlace?.name) ??
      (s?.toAirport?.label ?? s?.toAirport?.name) ??
      "";
    return typeof v === "string" ? v : (v?.label || v?.name || "");
  };

  const filledFlights = segs.filter(s => (
    flightFrom(s) || flightTo(s) || s.flightNumber || s.departTime || s.arriveTime
  ));

  const firstFlightWithNumber = filledFlights.find(s => (s.flightNumber || "").trim()) || null;
  const flightAwareUrl = firstFlightWithNumber
    ? `https://www.flightaware.com/live/flight/${(firstFlightWithNumber.flightNumber || "").trim().toUpperCase()}`
    : null;

  // Destination for maps actions
  const primaryPoint = day.transportMode === "geen"
    ? (day.startPoint || null)
    : (day.endPoint || null);

  const primaryText = day.transportMode === "geen"
    ? (day.startText || "")
    : (day.endText || "");

  const destDir = mapsDirUrl(primaryPoint || primaryText);
  const destSearch = mapsSearchUrl(primaryText);

  const hotelSearch = mapsSearchUrl(day.hotelAddress || day.hotelName);

  const mobileRouteMeta = useMemo(() => {
    if (!day || day.transportMode !== "auto") return null;
    const meters = day?.route?.distanceMeters;
    const secs = day?.route?.durationSeconds;
    if (meters == null && secs == null) return null;
    const km = meters != null ? formatKm(meters) : "";
    const dur = secs != null ? formatDuration(secs) : "";
    return { km, dur };
  }, [day]);

  // Activities: new structured list (day.activityItems) + backward compat for older text fields
  const activityItems = Array.isArray(day.activityItems) ? day.activityItems : [];
  const legacyActivities = (day.activitiesText || day.activityText || day.activities || "").toString().trim();
  const visibleActivities = activityItems.length
    ? activityItems
    : (legacyActivities ? [{ id: "legacy", time: "", title: legacyActivities, locationText: "", point: null }] : []);

  const activityMapsUrl = (a) => {
    if (a?.point?.lat != null && a?.point?.lng != null) {
      return `https://www.google.com/maps/search/?api=1&query=${a.point.lat},${a.point.lng}`;
    }
    const q = (a?.locationText || "").trim();
    return q ? mapsSearchUrl(q) : null;
  };

  return (
    <div className="mobileWrap">
      <header className="mobileHeader">
        <div className="mobileTopRow">
          <div>
            <div className="mobileTrip">{tripName || "Reis"}</div>
            <div className="mobileSub">{tripRange}</div>
            <div className="mobileSub2">{dayTitle}{dayDateLabel ? ` • ${dayDateLabel}` : ""}</div>
          </div>

          <div className="mobileNav">
            <button className="btn" disabled={dayIndex <= 0} onClick={() => goDay(day.dayNumber - 1)}>◀</button>
            <button className="btn" disabled={dayIndex >= (safeDays.length - 1)} onClick={() => goDay(day.dayNumber + 1)}>▶</button>
            <a className="mobileBack" href={baseUrl}>Planner</a>
          </div>
        </div>
      </header>

      <main className="mobileCard">
        <section className="mobileSection">
          <div className="sectionTitle">Reis</div>

          <div className="kvRow">
            <div className="kvKey">Transport</div>
            <div className="kvVal">{transportLabel(day.transportMode)}</div>
          </div>

          {/* Bij vliegtuig tonen we de vluchtsegmenten en niet nóg een keer start/eindbestemming. */}
          {day.transportMode !== "vliegtuig" && (
            <div className="kvRow">
              <div className="kvKey">Locatie</div>
              <div className="kvVal">
                {day.transportMode === "geen" ? (day.startText || "-") : `${day.startText || "-"} → ${day.endText || "-"}`}
              </div>
            </div>
          )}

          {/* Afstand/tijd tonen in telefoonweergave (voor auto-routes) */}
          {mobileRouteMeta && (mobileRouteMeta.km || mobileRouteMeta.dur) && (
            <>
              {mobileRouteMeta.km && (
                <div className="kvRow">
                  <div className="kvKey">Reisafstand</div>
                  <div className="kvVal">{mobileRouteMeta.km}</div>
                </div>
              )}
              {mobileRouteMeta.dur && (
                <div className="kvRow">
                  <div className="kvKey">Reistijd</div>
                  <div className="kvVal">{mobileRouteMeta.dur}</div>
                </div>
              )}
            </>
          )}

          {day.transportMode !== "vliegtuig" && Array.isArray(day.vias) && day.vias.filter(v => (v.text || "").trim()).length > 0 && (
            <div className="kvRow">
              <div className="kvKey">Via</div>
              <div className="kvVal">{day.vias.filter(v => (v.text || "").trim()).map(v => v.text).join(" • ")}</div>
            </div>
          )}

          {day.transportMode === "auto" && (day.autoKm || day.autoTime) && (
            <div className="kvRow">
              <div className="kvKey">Auto</div>
              <div className="kvVal">{day.autoKm ? `${day.autoKm} km` : ""}{day.autoTime ? ` • ${day.autoTime}` : ""}</div>
            </div>
          )}

          {day.transportMode === "vliegtuig" && (
            <div className="kvRow">
              <div className="kvKey">Vluchten</div>
              <div className="kvVal">
                {filledFlights.length === 0 ? (
                  <div className="muted">Geen vluchtsegmenten ingevuld</div>
                ) : (
                  filledFlights.map((s, i) => (
                    <div key={i} className="flightLine">
                      <div>
                        <strong>
                          {(flightFrom(s) || "?")}
                          {" → "}
                          {(flightTo(s) || "?")}
                        </strong>
                        {s.departTime ? ` • ${s.departTime}` : ""}{s.arriveTime ? `–${s.arriveTime}` : ""}
                      </div>
                      {(s.flightNumber || "").trim() ? (
                        <div className="muted" style={{ marginTop: 2 }}>{s.flightNumber}</div>
                      ) : null}
                    </div>
                  ))
                )}
              </div>
            </div>
          )}

          <div className="actionRow">
            {day.transportMode === "vliegtuig" ? (
              flightAwareUrl ? (
                <button className="btnPrimary" type="button" onClick={() => openUrl(flightAwareUrl)}>Controleer vlucht</button>
              ) : (
                <button className="btnPrimary" type="button" disabled>Controleer vlucht</button>
              )
            ) : (
              <>
                {destDir && <button className="btnPrimary" type="button" onClick={() => openUrl(destDir)}>Navigeer</button>}
                {!destDir && destSearch && <button className="btnPrimary" type="button" onClick={() => openUrl(destSearch)}>Open in Maps</button>}
              </>
            )}
          </div>
        </section>

        <section className="mobileSection">
          <div className="sectionTitle">Hotel</div>

          <div className="kvRow">
            <div className="kvKey">Naam</div>
            <div className="kvVal">{day.hotelName || "-"}</div>
          </div>

          <div className="kvRow">
            <div className="kvKey">Adres</div>
            <div className="kvVal">{day.hotelAddress || "-"}</div>
          </div>

          <div className="actionRow">
            {hotelSearch && <button className="btn" type="button" onClick={() => openUrl(hotelSearch)}>Open in Maps</button>}
            {(day.hotelLink || "").trim() && (
              <button className="btn" type="button" onClick={() => openUrl(day.hotelLink)}>Hotelpagina</button>
            )}
          </div>

          {(day.hotelCost != null || day.breakfastIncluded || day.extraCostLabel || day.extraCostAmount != null || day.hotelPaid) && (
            <div className="kvGrid">
              <div className="kvPill">{day.hotelCost != null && day.hotelCost !== "" ? `Kosten: ${money(day.hotelCost)}/nacht` : "Kosten: -"}</div>
              <div className={`kvPill ${day.breakfastIncluded ? "yes" : "no"}`}>{day.breakfastIncluded ? "Ontbijt: ja" : "Ontbijt: nee"}</div>
              <div className={`kvPill ${day.hotelPaid ? "yes" : "no"}`}>{day.hotelPaid ? "Betaald: ja" : "Betaald: nee"}</div>
              {(day.extraCostLabel || day.extraCostAmount != null) && (
                <div className="kvPill">
                  Extra: {(day.extraCostLabel || "kosten")}
                  {day.extraCostAmount != null && day.extraCostAmount !== "" ? ` (${money(day.extraCostAmount)})` : ""}
                </div>
              )}
            </div>
          )}
        </section>

        <section className="mobileSection">
          <div className="sectionTitle">Activiteiten</div>
          {visibleActivities.length === 0 ? (
            <div className="mobileText"><span className="muted">-</span></div>
          ) : (
            <div className="activityList">
              {visibleActivities
                .slice()
                .sort((a, b) => String(a?.time || "").localeCompare(String(b?.time || "")))
                .map((a) => {
                  const label = [a?.time, a?.title].filter(Boolean).join(" • ") || (a?.title || "-");
                  const loc = (a?.locationText || "").trim();
                  const url = activityMapsUrl(a);
                  return (
                    <div key={a.id} className="activityRow">
                      <div className="activityMain">
                        <div className="activityTitle">{autoLink(label) || label}</div>
                        {loc && <div className="activityLoc">{autoLink(loc) || loc}</div>}
                      </div>
                      {url && (
                        <button className="chipBtn" type="button" onClick={() => openUrl(url)}>
                          Maps
                        </button>
                      )}
                    </div>
                  );
                })}
            </div>
          )}

          <div className="dividerSmall" />

          <div className="sectionTitle">Notities</div>
          <div className="mobileText">{autoLink(day.notes) || <span className="muted">-</span>}</div>
        </section>

        <div className="mobileFooterNav">
          <button className="btn" disabled={dayIndex <= 0} onClick={() => goDay(day.dayNumber - 1)}>◀ Vorige</button>
          <button className="btn" disabled={dayIndex >= (safeDays.length - 1)} onClick={() => goDay(day.dayNumber + 1)}>Volgende ▶</button>
        </div>
      </main>
    </div>
  );
}
