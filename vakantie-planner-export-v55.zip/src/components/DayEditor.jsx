import React, { useMemo, useState } from "react";
import { geocodeCandidates } from "../utils/geocode.js";
import ResultPickerModal from "./ResultPickerModal.jsx";

const TRANSPORT_OPTIONS = [
  { value: "auto", label: "Auto" },
  { value: "vliegtuig", label: "Vliegtuig" },
  { value: "trein", label: "Trein" },
  { value: "boot", label: "Boot" },
  { value: "geen", label: "Geen (blijven op locatie)" }
];

function ensureSegments(day) {
  const segs = Array.isArray(day.flightSegments) ? day.flightSegments : [];
  if (segs.length >= 1) return segs;
  return [{ id: crypto.randomUUID(), from: "", to: "", fromPlace: null, toPlace: null, flightNumber: "", departTime: "", arriveTime: "" }];
}


function ensureActivities(day) {
  // New structured model: day.activityItems = [{ id, type, time, title, locationText, location, done, notes }]
  // Backward compat: if older field exists, convert it into a single activity item once.
  const items = Array.isArray(day.activityItems) ? day.activityItems : [];
  if (items.length) return items;

  const legacy = (day.activitiesText || day.activityText || day.activities || "").toString().trim();
  if (legacy) {
    return [
      {
        id: crypto.randomUUID(),
        type: "overig",
        time: "",
        title: legacy,
        locationText: "",
        location: null,
        done: false,
        notes: ""
      }
    ];
  }

  return [];
}

export default function DayEditor({ day, dayDateLabel, onChange, onGeocoded, onGeocodedVia }) {
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState("");
  const [pickState, setPickState] = useState(null); // { title, results, onPick }
  const [tab, setTab] = useState("reis");

  const title = useMemo(() => `Dag ${day.dayNumber}`, [day.dayNumber]);

  const isFlight = day.transportMode === "vliegtuig";
  const isNone = day.transportMode === "geen";
  const startLabel = isNone ? "Verblijflocatie" : "Startbestemming";
  const vias = Array.isArray(day.vias) ? day.vias : [];
  const flightSegments = ensureSegments(day);
  const activityItems = ensureActivities(day);

  async function geocodeFlight(segId, which) {
    setErr("");
    setBusy(true);
    try {
      const seg = flightSegments.find((s) => s.id === segId);
      const query = ((which === "from" ? seg?.from : seg?.to) ?? "").trim();
      if (!query) return;

      const results = await geocodeCandidates(query, { limit: 6 });
      if (!results.length) {
        setErr(`Geen locatie gevonden voor: "${query}"`);
        return;
      }

      const applyPick = (r) => {
        const nextSegs = flightSegments.map((s) => {
          if (s.id !== segId) return s;
          if (which === "from") return { ...s, from: r.label, fromPlace: { label: r.label, lat: r.lat, lng: r.lng } };
          return { ...s, to: r.label, toPlace: { label: r.label, lat: r.lat, lng: r.lng } };
        });
        // Keep legacy start/end fields in sync so summaries / export stay sane.
        const first = nextSegs[0];
        const last = nextSegs[nextSegs.length - 1];
        onChange({
          ...day,
          flightSegments: nextSegs,
          startText: (first?.from ?? day.startText ?? ""),
          endText: (last?.to ?? day.endText ?? ""),
          startPoint: first?.fromPlace ? { lat: first.fromPlace.lat, lng: first.fromPlace.lng } : day.startPoint,
          endPoint: last?.toPlace ? { lat: last.toPlace.lat, lng: last.toPlace.lng } : day.endPoint,
        });
      };

      if (results.length === 1) {
        applyPick(results[0]);
        return;
      }

      setPickState({
        title: `Kies juiste ${which === "from" ? "vertreklocatie" : "bestemming"} voor vlucht`,
        results,
        onPick: (r) => {
          setPickState(null);
          applyPick(r);
        },
      });
    } catch (e) {
      setErr(e?.message || "Geocoding fout");
    } finally {
      setBusy(false);
    }
  }

  async function geocode(which) {
    setErr("");
    setBusy(true);
    try {
      const query = (which === "start" ? day.startText : day.endText)?.trim();
      const results = await geocodeCandidates(query, { limit: 6 });

      if (!results.length) {
        setErr(`Geen locatie gevonden voor: "${query}"`);
        return;
      }

      if (results.length === 1) {
        onGeocoded(which, results[0]);
        return;
      }

      setPickState({
        title: `Kies bestemming voor ${which === "start" ? "locatie" : "eindbestemming"}`,
        results,
        onPick: (r) => {
          setPickState(null);
          onGeocoded(which, r);
        }
      });
    } catch (e) {
      setErr(e?.message || "Geocoding fout");
    } finally {
      setBusy(false);
    }
  }

  async function geocodeVia(viaId) {
    setErr("");
    setBusy(true);
    try {
      const via = vias.find((v) => v.id === viaId);
      const query = (via?.text ?? "").trim();
      const results = await geocodeCandidates(query, { limit: 6 });

      if (!results.length) {
        setErr(`Geen locatie gevonden voor: "${query}"`);
        return;
      }

      if (results.length === 1) {
        onGeocodedVia(viaId, results[0]);
        return;
      }

      setPickState({
        title: "Kies juiste via-bestemming",
        results,
        onPick: (r) => {
          setPickState(null);
          onGeocodedVia(viaId, r);
        }
      });
    } catch (e) {
      setErr(e?.message || "Geocoding fout");
    } finally {
      setBusy(false);
    }
  }

  function openMapsFromPointOrText(point, text) {
    if (point && typeof point.lat === "number" && typeof point.lng === "number") {
      const url = `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(`${point.lat},${point.lng}`)}`;
      window.open(url, "_blank", "noopener,noreferrer");
      return;
    }
    const q = (text || "").trim();
    if (!q) return;
    const url = `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(q)}`;
    window.open(url, "_blank", "noopener,noreferrer");
  }

  function onGeocodedActivity(activityId, result) {
    const next = activityItems.map((a) =>
      a.id === activityId
        ? {
            ...a,
            locationText: result.displayName || a.locationText,
            point: { lat: result.lat, lng: result.lng },
          }
        : a
    );
    onChange({ ...day, activityItems: next });
  }

  async function geocodeActivity(activityId) {
    setErr("");
    const a = activityItems.find((x) => x.id === activityId);
    const q = (a?.locationText || "").trim();
    if (!q) return;

    setBusy(true);
    try {
      const results = await geocodeCandidates(q, { limit: 6 });

      if (!results.length) {
        setErr(`Geen locatie gevonden voor: "${q}"`);
        return;
      }

      if (results.length === 1) {
        onGeocodedActivity(activityId, results[0]);
        return;
      }

      setPickState({
        title: "Kies juiste locatie voor activiteit",
        results,
        onPick: (r) => {
          setPickState(null);
          onGeocodedActivity(activityId, r);
        }
      });
    } catch (e) {
      setErr(e?.message || "Geocoding fout");
    } finally {
      setBusy(false);
    }
  }


  function onTransportChange(nextMode) {
    const base = { ...day, transportMode: nextMode };

    if (nextMode === "geen") {
      base.endText = "";
      base.endPoint = null;
      base.vias = [];
      base.route = null;
    }

    if (nextMode !== "vliegtuig") {
      base.flightSegments = ensureSegments(base).slice(0, 1);
    }

    onChange(base);
  }

  return (
    <div>
      {pickState && (
        <ResultPickerModal
          title={pickState.title}
          results={pickState.results}
          onPick={pickState.onPick}
          onClose={() => setPickState(null)}
        />
      )}

      <div className="row">
        <div>
          <span className="badge">{title}</span>
          <span className="small">{dayDateLabel ? `• ${dayDateLabel}` : ""}</span>
        </div>
      </div>

      <div className="divider" />

      <div className="tabs">
        <button className={tab === "reis" ? "tab active" : "tab"} onClick={() => setTab("reis")}>Reis</button>
        <button className={tab === "hotel" ? "tab active" : "tab"} onClick={() => setTab("hotel")}>Hotel</button>
        <button className={tab === "activiteiten" ? "tab active" : "tab"} onClick={() => setTab("activiteiten")}>Activiteiten</button>
      </div>

      {tab === "reis" && (
        <>
      {/* 1) Transport */}
      <div className="row">
        <div>
          <label>Transport</label>
          <select value={day.transportMode} onChange={(e) => onTransportChange(e.target.value)}>
            {TRANSPORT_OPTIONS.map((o) => (
              <option key={o.value} value={o.value}>
                {o.label}
              </option>
            ))}
          </select>
        </div>
      </div>

      <div className="divider" />

      {/* 2) Bestemmingen */}
      {!isFlight && (
        <div className="row">
          <div>
            <label>{startLabel}</label>
            <input
              value={day.startText || ""}
              placeholder={isNone ? "Bijv. Moab" : "Bijv. Amsterdam"}
              onChange={(e) => onChange({ ...day, startText: e.target.value, startAutoFromPrev: false })}
            />
          </div>
          <div style={{ flex: "0 0 120px" }}>
            <label>&nbsp;</label>
            <button disabled={busy || !(day.startText || "").trim()} onClick={() => geocode("start")}>
              Zoek
            </button>
          </div>
        </div>
      )}

      {!isNone && (
        <React.Fragment>
          {!isFlight && (
            <>
              <div className="divider" style={{ marginTop: 10, marginBottom: 10 }} />

              <div className="row" style={{ alignItems: "baseline" }}>
                <div>
                  <label>Via (tussenbestemmingen)</label>
                  <div className="small">Auto: via's tellen mee in route.</div>
                </div>
                <div style={{ flex: "0 0 160px" }}>
                  <button
                    className="secondary"
                    onClick={() =>
                      onChange({
                        ...day,
                        vias: [...vias, { id: crypto.randomUUID(), text: "", point: null }],
                        route: null
                      })
                    }
                  >
                    + Via toevoegen
                  </button>
                </div>
              </div>

              {vias.length > 0 && (
                <div className="viaList" style={{ marginTop: 8 }}>
                  {vias.map((v, idx) => (
                    <div key={v.id} className="viaRow">
                      <div>
                        <label>Via {idx + 1}</label>
                        <input
                          value={v.text || ""}
                          placeholder="Bijv. Luxemburg stad"
                          onChange={(e) => {
                            const nextVias = vias.map((x) =>
                              x.id === v.id ? { ...x, text: e.target.value, point: null } : x
                            );
                            onChange({ ...day, vias: nextVias, route: null });
                          }}
                        />
                      </div>
                      <div>
                        <label>&nbsp;</label>
                        <button disabled={busy || !(v.text || "").trim()} onClick={() => geocodeVia(v.id)}>
                          Zoek
                        </button>
                      </div>
                      <div>
                        <label>&nbsp;</label>
                        <button
                          className="danger"
                          title="Verwijderen"
                          onClick={() => {
                            const nextVias = vias.filter((x) => x.id !== v.id);
                            onChange({ ...day, vias: nextVias, route: null });
                          }}
                        >
                          ×
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}

              <div className="divider" style={{ marginTop: 10, marginBottom: 10 }} />

              <div className="row">
                <div>
                  <label>Eindbestemming</label>
                  <input
                    value={day.endText || ""}
                    placeholder="Bijv. Trier"
                    onChange={(e) => onChange({ ...day, endText: e.target.value })}
                  />
                </div>
                <div style={{ flex: "0 0 120px" }}>
                  <label>&nbsp;</label>
                  <button disabled={busy || !(day.endText || "").trim()} onClick={() => geocode("end")}>
                    Zoek
                  </button>
                </div>
              </div>
            </>
          )}

          {/* 3) Vliegtuigdetails (tussen bestemming en hotel) */}
          {isFlight && (
            <>
              <div className="divider" style={{ marginTop: 12, marginBottom: 12 }} />
              <div className="row" style={{ alignItems: "baseline" }}>
                <div>
                  <label>Vlucht(en)</label>
                  <div className="small">
                    Leg per vluchtsegment vast: <b>van</b> → <b>naar</b>, tijden en vluchtnummer.
                  </div>
                </div>
                <div style={{ flex: "0 0 220px" }}>
                  <button
                    className="secondary"
                    onClick={() =>
                      onChange({
                        ...day,
                        flightSegments: [
                          ...flightSegments,
                          {
                            id: crypto.randomUUID(),
                            from: "",
                            to: "",
                            fromPlace: null,
                            toPlace: null,
                            departTime: "",
                            arriveTime: "",
                            flightNumber: "",
                          },
                        ],
                      })
                    }
                  >
                    + vlucht toevoegen
                  </button>
                </div>
              </div>

              <div className="flightList" style={{ marginTop: 8 }}>
                {flightSegments.map((seg, idx) => (
                  <div key={seg.id} className="card" style={{ padding: 10, marginBottom: 8 }}>
                    <div className="row" style={{ alignItems: "center" }}>
                      <div style={{ fontWeight: 700 }}>
                        {(() => {
                          const from = (seg.from || "").trim();
                          const to = (seg.to || "").trim();
                          if (from || to) return `Vlucht ${from || "…"} - ${to || "…"}`;
                          return `Vlucht ${idx + 1}`;
                        })()}
                      </div>
                      <div style={{ flex: 1 }} />
                      {flightSegments.length > 1 && (
                        <button
                          className="danger"
                          title="Verwijderen"
                          onClick={() =>
                            onChange({
                              ...day,
                              flightSegments: flightSegments.filter((x) => x.id !== seg.id),
                            })
                          }
                        >
                          ×
                        </button>
                      )}
                    </div>

                    <div className="row" style={{ marginTop: 8, alignItems: "flex-end" }}>
                      <div style={{ flex: 1 }}>
                        <label>Van</label>
                        <div className="row" style={{ gap: 8 }}>
                          <input
                            value={seg.from || ""}
                            placeholder="Bijv. Amsterdam"
                            onChange={(e) => {
                              const next = flightSegments.map((x) => (x.id === seg.id ? { ...x, from: e.target.value } : x));
                              const first = next[0];
                              const last = next[next.length - 1];
                              onChange({ ...day, flightSegments: next, startText: first?.from ?? day.startText, endText: last?.to ?? day.endText });
                            }}
                          />
                          <button
                            style={{ flex: "0 0 90px" }}
                            disabled={busy || !(seg.from || "").trim()}
                            onClick={() => geocodeFlight(seg.id, "from")}
                          >
                            Zoek
                          </button>
                        </div>
                      </div>

                      <div style={{ flex: 1 }}>
                        <label>Naar</label>
                        <div className="row" style={{ gap: 8 }}>
                          <input
                            value={seg.to || ""}
                            placeholder="Bijv. Vancouver"
                            onChange={(e) => {
                              const next = flightSegments.map((x) => (x.id === seg.id ? { ...x, to: e.target.value } : x));
                              const first = next[0];
                              const last = next[next.length - 1];
                              onChange({ ...day, flightSegments: next, startText: first?.from ?? day.startText, endText: last?.to ?? day.endText });
                            }}
                          />
                          <button
                            style={{ flex: "0 0 90px" }}
                            disabled={busy || !(seg.to || "").trim()}
                            onClick={() => geocodeFlight(seg.id, "to")}
                          >
                            Zoek
                          </button>
                        </div>
                      </div>
                    </div>

                    <div className="row" style={{ marginTop: 8 }}>
                      <div>
                        <label>Vertrek</label>
                        <input
                          type="time"
                          value={seg.departTime || ""}
                          onChange={(e) => {
                            const next = flightSegments.map((x) => (x.id === seg.id ? { ...x, departTime: e.target.value } : x));
                            onChange({ ...day, flightSegments: next });
                          }}
                        />
                      </div>

                      <div>
                        <label>Aankomst</label>
                        <input
                          type="time"
                          value={seg.arriveTime || ""}
                          onChange={(e) => {
                            const next = flightSegments.map((x) => (x.id === seg.id ? { ...x, arriveTime: e.target.value } : x));
                            onChange({ ...day, flightSegments: next });
                          }}
                        />
                      </div>

                      <div>
                        <label>Vluchtnummer</label>
                        <input
                          value={seg.flightNumber || ""}
                          placeholder="Bijv. KL1234"
                          onChange={(e) => {
                            const next = flightSegments.map((x) => (x.id === seg.id ? { ...x, flightNumber: e.target.value } : x));
                            onChange({ ...day, flightSegments: next });
                          }}
                        />
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </>
          )}</React.Fragment>
      )}

      <div className="divider" />

        </>
      )}

      {tab === "hotel" && (
        <>
      {/* 4) Hotel (onder bestemmingen / vlucht) */}
      <div>
        <label>Hotel (naam)</label>
        <input
          value={day.hotelName || ""}
          placeholder="Bijv. Best Western ..."
          onChange={(e) => onChange({ ...day, hotelName: e.target.value })}
        />
      </div>

      <div className="row" style={{ alignItems: "flex-end" }}>
        <div style={{ flex: 1, minWidth: 220 }}>
          <label>Hotel adres</label>
          <input
            value={day.hotelAddress || ""}
            placeholder="Straat + plaats (liefst zo specifiek mogelijk)"
            onChange={(e) => onChange({ ...day, hotelAddress: e.target.value })}
          />
        </div>
        <div style={{ flex: "0 0 auto", minWidth: "auto" }}>
          <button
            type="button"
            className="secondary"
            style={{ width: "auto", whiteSpace: "nowrap", padding: "10px 14px" }}
            onClick={() => {
              const addr = (day.hotelAddress || "").trim();
              if (!addr) return;
              const url = `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(addr)}`;
              window.open(url, "_blank");
            }}
          >
            Open in Maps
          </button>
        </div>
      </div>


      <div className="row">
        <div>
          <label>Hotel link</label>
          <input
            value={day.hotelLink || ""}
            placeholder="https://..."
            onChange={(e) => onChange({ ...day, hotelLink: e.target.value })}
          />
          {(day.hotelLink || "").trim() && (
            <div className="small" style={{ marginTop: 6 }}>
              <a className="inlineLink" href={day.hotelLink} target="_blank" rel="noreferrer">
                Open hotelpagina
              </a>
            </div>
          )}
        </div>
        <div>
          <label>Hotel kosten (per nacht)</label>
          <input
            type="number"
            step="0.01"
            value={day.hotelCost ?? ""}
            placeholder="Bijv. 149.00"
            onChange={(e) => {
              const v = e.target.value;
              onChange({ ...day, hotelCost: v === "" ? null : Number(v) });
            }}
          />
        </div>
      </div>

      <div className="row">
        <div>
          <label>Ontbijt</label>
          <div className="checkboxRow">
            <input
              type="checkbox"
              checked={!!day.breakfastIncluded}
              onChange={(e) => onChange({ ...day, breakfastIncluded: e.target.checked })}
            />
            <span className="small">Ontbijt inbegrepen</span>
          </div>
        </div>

        <div>
          <label>Betaald</label>
          <div className="checkboxRow">
            <input
              type="checkbox"
              checked={!!day.hotelPaid}
              onChange={(e) => onChange({ ...day, hotelPaid: e.target.checked })}
            />
            <span className="small">Hotel al betaald</span>
          </div>
        </div>
      </div>

            <div className="row" style={{ alignItems: "flex-end" }}>
        <div>
          <label>Extra kosten (omschrijving)</label>
          <input
            value={day.extraCostLabel || ""}
            placeholder="Bijv. parkeren"
            onChange={(e) => onChange({ ...day, extraCostLabel: e.target.value })}
          />
        </div>
        <div>
          <label>Extra kosten (bedrag)</label>
          <input
            type="number"
            step="0.01"
            value={day.extraCostAmount ?? ""}
            placeholder="Bijv. 18.50"
            onChange={(e) => {
              const v = e.target.value;
              onChange({ ...day, extraCostAmount: v === "" ? null : Number(v) });
            }}
          />
        </div>
        <div className="small" style={{ flex: "1 1 100%", marginTop: -4 }}>
          Tip: vul bedrag in als het meetelt voor totals.
        </div>
      </div>

      <div className="divider" />

        </>
      )}

      {tab === "activiteiten" && (
            <>
              <div className="row" style={{ alignItems: "baseline" }}>
                <div>
                  <label>Activiteiten</label>
                  <div className="small">Maak een lijstje met tijd, omschrijving en locatie (optioneel).</div>
                </div>
                <div style={{ flex: "0 0 220px" }}>
                  <button
                    className="secondary"
                    onClick={() =>
                      onChange({
                        ...day,
                        activityItems: [
                          ...activityItems,
                          { id: crypto.randomUUID(), time: "", title: "", locationText: "", point: null },
                        ],
                      })
                    }
                  >
                    + activiteit
                  </button>
                </div>
              </div>

              {activityItems.length === 0 ? (
                <div className="small" style={{ marginTop: 8, opacity: 0.8 }}>
                  Nog geen activiteiten toegevoegd.
                </div>
              ) : (
                <div style={{ marginTop: 8 }}>
                  {activityItems.map((a, idx) => (
                    <div key={a.id} className="card" style={{ padding: 10, marginBottom: 8 }}>
                      <div className="row" style={{ alignItems: "center" }}>
                        <div style={{ fontWeight: 700 }}>Activiteit {idx + 1}</div>
                        <div style={{ flex: 1 }} />
                        <button
                          className="danger"
                          title="Verwijderen"
                          onClick={() =>
                            onChange({
                              ...day,
                              activityItems: activityItems.filter((x) => x.id !== a.id),
                            })
                          }
                        >
                          ×
                        </button>
                      </div>

                      <div className="row" style={{ marginTop: 8 }}>
                        <div style={{ flex: "0 0 140px" }}>
                          <label>Tijd (optioneel)</label>
                          <input
                            type="time"
                            value={a.time || ""}
                            onChange={(e) => {
                              const next = activityItems.map((x) => (x.id === a.id ? { ...x, time: e.target.value } : x));
                              onChange({ ...day, activityItems: next });
                            }}
                          />
                        </div>

                        <div style={{ flex: 1 }}>
                          <label>Omschrijving</label>
                          <input
                            value={a.title || ""}
                            placeholder="Bijv. Trail: Lake Agnes"
                            onChange={(e) => {
                              const next = activityItems.map((x) => (x.id === a.id ? { ...x, title: e.target.value } : x));
                              onChange({ ...day, activityItems: next });
                            }}
                          />
                        </div>
                      </div>

                      <div className="row" style={{ marginTop: 8 }}>
                        <div style={{ flex: 1 }}>
                          <label>Locatie (optioneel)</label>
                          <input
                            value={a.locationText || ""}
                            placeholder="Bijv. Lake Louise Trailhead"
                            onChange={(e) => {
                              const next = activityItems.map((x) =>
                                x.id === a.id ? { ...x, locationText: e.target.value, point: null } : x
                              );
                              onChange({ ...day, activityItems: next });
                            }}
                          />
                        </div>

                        <div style={{ flex: "0 0 120px" }}>
                          <label>&nbsp;</label>
                          <button disabled={busy || !(a.locationText || "").trim()} onClick={() => geocodeActivity(a.id)}>
                            Zoek
                          </button>
                        </div>

                        <div style={{ flex: "0 0 140px" }}>
                          <label>&nbsp;</label>
                          <button
                            className="secondary"
                            disabled={!(a.locationText || "").trim() && !a.point}
                            onClick={() => openMapsFromPointOrText(a.point, a.locationText)}
                          >
                            Open in Maps
                          </button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}

              <div className="divider" style={{ marginTop: 12, marginBottom: 12 }} />

              <div>
                <label>Notities</label>
                <textarea
                  value={day.notes || ""}
                  placeholder="Vrije notities voor deze dag…"
                  onChange={(e) => onChange({ ...day, notes: e.target.value })}
                />
              </div>
            </>
          )}

      {err && (
        <div className="small" style={{ color: "crimson", marginTop: 6 }}>
          {err}
        </div>
      )}
    </div>
  );
}